package com.example.admin.being_human;

/**
 * Created by kulsoom on 29-Dec-17.
 */

public class UiComponent {
}

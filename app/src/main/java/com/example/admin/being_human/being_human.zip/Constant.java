package com.example.admin.being_human;

/**
 * Created by kulsoom on 11-Jan-18.
 */

class Constant {
    public static final String LOCATION_LATITUDE = "latitude";
    public static final String LOCATION_LONGITUDE = "longitude";
    public static final String LOGSTATUS = "0";
    public static final String USERNAME = "name";
    public static final String USERBLOODGROUP = "blood";
    public static final String USERAGE = "age";
    public static final String USERGENDER = "gender";
    public static final String USERLASTDONATION = "donation";
    public static final String USERCITY = "city";
    public static final String USERPHONENUM = "phone";
    public static final String USEREMAIL = "mail";
    public static final String USERPASS = "pass";
    public static final String DOANRSTATUS = "dstatus";

}
